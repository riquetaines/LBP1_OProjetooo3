class Pessoa:
    def __init__(self, id, nome, senha):
        self.id = id
        self.nome = nome
        self.senha = senha

    def __str__(self):
        return f"ID: {self.id}, Nome: {self.nome}"

pessoas = []

def add_pessoa(nome, senha):
    if not nome or not senha:
        raise ValueError("Nome e senha não podem ser vazios.")
    
    id = len(pessoas) + 1
    nova_pessoa = Pessoa(id, nome, senha)
    pessoas.append(nova_pessoa)