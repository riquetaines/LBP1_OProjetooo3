from flask import Flask, render_template, request, redirect, url_for, flash, session
from model.model import Pessoa, pessoas, add_pessoa

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.errorhandler(401)
def unauthorized(e):
    return render_template('401.html'), 401

@app.errorhandler(403)
def forbidden(e):
    return render_template('403.html'), 403

@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(e):
    return render_template('500.html'), 500

@app.route('/')
def index():
    return redirect(url_for('register'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    errors = {}
    if request.method == 'POST':
        nome = request.form.get("nome")
        senha = request.form.get("senha")
        
        if nome is None or len(nome) < 3:
            errors['nome'] = 'O nome deve ter pelo menos 3 caracteres.'
        if senha is None or len(senha) < 8:
            errors['senha'] = 'A senha deve ter pelo menos 8 caracteres.'

        if not errors:
            add_pessoa(nome, senha)
            flash('Cadastro bem-sucedido! Faça login para continuar.')
            return redirect(url_for('login'))
    return render_template('register.html', errors=errors)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nome = request.form.get("nome")
        senha = request.form.get("senha")
        
        if nome is None or senha is None:
            flash('Por favor, preencha todos os campos.')
            return render_template('login.html', errors={})

        for pessoa in pessoas:
            if pessoa.nome == nome and pessoa.senha == senha:
                session['user'] = nome
                flash('Login bem-sucedido!')
                return redirect(url_for('dashboard'))

        flash('Nome ou senha incorretos!')
    return render_template('login.html', errors={})

@app.route('/dashboard')
def dashboard():
    if 'user' in session:
        return render_template('dashboard.html', user=session['user'])
    else:
        flash('Você precisa fazer login primeiro.')
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Você foi desconectado.')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
