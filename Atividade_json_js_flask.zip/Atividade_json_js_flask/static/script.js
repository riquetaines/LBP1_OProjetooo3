document.addEventListener("DOMContentLoaded", function() {
    // Carrega os itens da página inicial
    loadItems(1);

    function loadItems(page) {
        // Faz uma requisição para pegar os itens da página atual
        fetch(`/items?page=${page}`)
            .then(response => response.json())
            .then(data => {
                // Moztra os itens e a paginação com base na resposta
                displayItems(data.items);
                displayPagination(data.page, data.total_pages);
            });
    }

    function displayItems(items) {
        // Pega o contêiner onde os itens serão mostrados
        const itemsList = document.getElementById("items-list");
        itemsList.innerHTML = ""; // Limpa o conteúdo atual
        items.forEach(item => {
            // Cria um elemento para cada item
            const itemDiv = document.createElement("div");
            itemDiv.textContent = item.name; // Define o nome do item como texto
            itemDiv.classList.add("item"); // Adiciona uma classe CSS
            itemDiv.onclick = () => loadItemDetails(item.id); // Define um evento de clique
            itemsList.appendChild(itemDiv); // Adiciona o item ao contêiner
        });
    }

    function displayPagination(currentPage, totalPages) {
        // Pega o contêiner onde os botões de paginação serão mostrados
        const pagination = document.getElementById("pagination");
        pagination.innerHTML = ""; // Limpa o conteúdo atual

        for (let i = 1; i <= totalPages; i++) {
            // Cria um botão para cada página
            const pageButton = document.createElement("button");
            pageButton.textContent = i; // Define o número da página como texto
            pageButton.onclick = () => loadItems(i); // Define um evento de clique para carregar a página correspondente
            if (i === currentPage) {
                pageButton.disabled = true; // Desabilita o botão da página atual
            }
            pagination.appendChild(pageButton); // Adiciona o botão ao contêiner de paginação
        }
    }

    function loadItemDetails(itemId) {
        // Faz uma requisição para pegar os detalhes de um item específico
        fetch(`/items/${itemId}`)
            .then(response => response.json())
            .then(item => {
                // Pega o contêiner onde os detalhes do item serão mostrados
                const itemDetails = document.getElementById("item-details");
                if (item.error) {
                    // Mostra um erro, se existir
                    itemDetails.innerHTML = item.error;
                } else {
                    // Mostra os detalhes do item
                    itemDetails.innerHTML = `<h2>${item.name}</h2><p>${item.description}</p>`;
                }
            });
    }
});
