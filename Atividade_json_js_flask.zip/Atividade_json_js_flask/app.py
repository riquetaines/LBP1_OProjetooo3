from flask import Flask, render_template, request
import json
import math

app = Flask(__name__)  # Cria a aplicação Flask

def load_items():
    # Carrega os itens do arquivo json
    with open('dados/items.json') as f:
        return json.load(f)

@app.route('/')
def index():
    # Pega o número da página a partir dos parâmetros da URL (default: 1)
    page = int(request.args.get('page', 1))
    per_page = 3  # Número de itens por página
    items = load_items()  # Carrega todos os itens
    
    total_items = len(items)  # Total de itens disponíveis
    total_pages = math.ceil(total_items / per_page)  # Calcula o total de páginas
    start = (page - 1) * per_page  # Índice inicial dos itens da página atual
    end = start + per_page  # Índice final dos itens da página atual
    paginated_items = items[start:end]  # Pega apenas os itens da página atual

    # Determina se existem páginas anterior e próxima
    next_page = page + 1 if page < total_pages else None
    prev_page = page - 1 if page > 1 else None
    
    # Renderiza o template com os itens e dados de paginação
    return render_template('pagina1.html', items=paginated_items, page=page, total_pages=total_pages, next_page=next_page, prev_page=prev_page)

if __name__ == '__main__':
    app.run(debug=True)  # Inicia o servidor em modo de depuração
