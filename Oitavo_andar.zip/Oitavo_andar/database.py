from flask_sqlalchemy import SQLAlchemy

# Inicializando o objeto db
db = SQLAlchemy()

# Função para inicializar o banco de dados
def init_db(app):
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///imoveis.db'  # Usando SQLite
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Inicializa o banco de dados com o Flask app
    with app.app_context():
        db.init_app(app)
        db.create_all()  # Cria todas as tabelas definidas
