from model.model import Imovel, Realtor, db

class ImovelDAO:
    @staticmethod
    def add_imovel(id, nome, tipo, descricao, quartos,banheiros, m2, preco, imagem):
        imovel=Imovel(
            id = id,
            nome=nome,
            tipo=tipo,
            descricao=descricao,
            quartos=quartos,
            banheiros=banheiros,
            m2=m2,
            preco=preco,
            imagem=imagem
        )
        db.session.add(imovel)
        db.session.commit()
        return imovel
    
    @staticmethod
    def get_imovel_id(id):
        imovel = Imovel.query.get(id)
        if not imovel:
            return None, "Imovel não encontrado"
        
        return imovel, None
    
class UserDAO:
    @staticmethod
    def add_usuario(user, senha):
        usuario= Realtor(
            user = user,
            senha = senha
        )
        db.session.add(usuario)
        db.session.commit()
        return usuario
    
    @staticmethod
    def get_user_id(id):
        usuario = Realtor.query.get(id)
        if not usuario:
            return None, "Usuario não encontrado"
        
        return usuario, None