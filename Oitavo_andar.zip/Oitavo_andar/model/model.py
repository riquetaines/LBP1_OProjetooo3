from flask_sqlalchemy import SQLAlchemy

# Inicializando o banco de dados
db = SQLAlchemy()

# Modelo de Imóvel
class Imovel(db.Model):
    __tablename__ = 'imoveis'  # Nome da tabela no banco de dados

    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(20))
    nome = db.Column(db.String(100))
    descricao = db.Column(db.String(255))
    quartos = db.Column(db.Integer)
    banheiros = db.Column(db.Integer)
    m2 = db.Column(db.Integer)
    preco = db.Column(db.Float)
    imagem = db.Column(db.String(255))

# Modelo de Corretor
class Realtor(db.Model):
    __tablename__ = 'realtors'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

# Função para inicializar o banco de dados
def init_db():
    db.create_all()  # Cria as tabelas no banco de dados

# Função para obter todos os imóveis de um tipo
def get_all_properties(tipo):
    return Imovel.query.filter_by(tipo=tipo).all()

# Função para obter um imóvel pelo ID
def get_property_by_id(id):
    return Imovel.query.get(id)

# Função para validar o login de um corretor
def validate_realtor_login(username, password):
    realtor = Realtor.query.filter_by(username=username, password=password).first()
    return realtor
