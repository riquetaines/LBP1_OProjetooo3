from flask import Flask, Blueprint, request, session, render_template, redirect, url_for, jsonify
from model.model import init_db,get_property_by_id, get_all_properties, validate_realtor_login
from repository import *

app = Flask(__name__)
app2 = Blueprint('imovel', __name__)
app.secret_key = "key_secreta"
imovelrepo=ImovelRepository
init_db(app)

@app.route('/')
def index():
    properties = get_all_properties()
    return render_template('index.html', properties=properties)

@app.route('/login_corretor', methods=['GET', 'POST'])
def login_corretor():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Validar o login com a função de validação
        realtor = validate_realtor_login(username, password)
        
        if realtor:  # Se o corretor for encontrado
            session['realtor_id'] = realtor.id  # Salvando o ID do corretor na sessão
            session['realtor_username'] = realtor.username  # Opcional: salvar o nome de usuário
            return redirect(url_for('index'))  # Redireciona para a página inicial após login
        else:
            # Caso falhe a autenticação
            return render_template('login_corretor.html', error="Usuário ou senha inválidos")
    return render_template('login_corretor.html')  # GET request exibe o formulário de login

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'realtor_id' not in session:  # Se não estiver logado
            return redirect(url_for('login_corretor'))  # Redireciona para a página de login
        return f(*args, **kwargs)
    return decorated_function
def venda():
    # Obtém todos os imóveis para venda
    imoveis_venda = get_all_properties()  # Você pode precisar filtrar para apenas imóveis para venda
    return render_template('venda.html', imoveis=imoveis_venda)

@app.route('/locacao')
def locacao():
    # Obtém todos os imóveis para aluguel
    imoveis_locacao = get_all_properties()  # Você pode precisar filtrar para apenas imóveis para aluguel
    return render_template('locacao.html', imoveis=imoveis_locacao)

# Rota para detalhes de venda
@app.route('/detalhes_venda/<int:id>')
def detalhes_venda(id):
    # Obtém as informações detalhadas do imóvel para venda
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_venda.html', property=property)
    return "Imóvel não encontrado", 404

# Rota para detalhes de locação
@app.route('/detalhes_locacao/<int:id>')
def detalhes_locacao(id):
    # Obtém as informações detalhadas do imóvel para locação
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_locacao.html', property=property)
    return "Imóvel não encontrado", 404

@app.route('/property/<int:id>')
def property_details_route(id):
    property = get_property_by_id(id)
    if property:
        return render_template('property_details.html', property=property)
    return "Imóvel não encontrado", 404

if __name__ == '__main__':
    app.run(debug=True)

@app.route('/comprar/<int:id>')
def detalhes_venda(id):
    # Obtém as informações detalhadas do imóvel para venda
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_venda.html', property=property)
    return "Imóvel não encontrado", 404

@app.route('/alugar/<int:id>')
def detalhes_locacao(id):
    # Obtém as informações detalhadas do imóvel para locação
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_locacao.html', property=property)
    return "Imóvel não encontrado", 404

@app2.route('/add_imovel', methods=['POST'])
@login_required
def add_imovel_route():
    data= request.json
    id = data.get('id')
    nome = data.get('nome')
    tipo = data.get('tipo')
    descricao=data.get('descricao')
    quartos=data.get('quartos')
    banheiros=data.get('banheiros')
    m2=data.get('m2')
    preco=data.get('preco')
    imagem=data.get('imagem')

    return imovelrepo.add_imovel(id, nome, tipo, descricao, quartos,banheiros, m2, preco, imagem)

@app2.route('imovel', methods=['GET'])
def get_imovel_route():
    id = request.args.get('id')

    return imovelrepo.get_imovel_id(id)

@app.route('/logout')
def logout():
    session.pop('realtor_id', None)  # Remove o ID do corretor da sessão
    session.pop('realtor_username', None)  # Remove o nome do corretor da sessão
    return redirect(url_for('login_corretor'))  # Redireciona para a página de login
