from flask import Flask, request, session, render_template, redirect, url_for
from model import get_property_by_id, get_all_properties, mark_as_sold, mark_as_rented, validate_realtor_login

app = Flask(__name__)
app.secret_key = "key_secreta"

@app.route('/')
def index():
    properties = get_all_properties()
    return render_template('index.html', properties=properties)

@app.route('/login_corretor', methods=['GET', 'POST'])
def login_corretor():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        realtor = validate_realtor_login(username, password)
        if realtor:
            session['realtor_id'] = realtor[0]  # Salvando o ID do corretor na sessão
            return redirect(url_for('index'))
        else:
            return "Login inválido"
    return render_template('login_corretor.html')

@app.route('/venda')
def venda():
    # Obtém todos os imóveis para venda
    imoveis_venda = get_all_properties()  # Você pode precisar filtrar para apenas imóveis para venda
    return render_template('venda.html', imoveis=imoveis_venda)

@app.route('/locacao')
def locacao():
    # Obtém todos os imóveis para aluguel
    imoveis_locacao = get_all_properties()  # Você pode precisar filtrar para apenas imóveis para aluguel
    return render_template('locacao.html', imoveis=imoveis_locacao)

# Rota para detalhes de venda
@app.route('/detalhes_venda/<int:id>')
def detalhes_venda(id):
    # Obtém as informações detalhadas do imóvel para venda
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_venda.html', property=property)
    return "Imóvel não encontrado", 404

# Rota para detalhes de locação
@app.route('/detalhes_locacao/<int:id>')
def detalhes_locacao(id):
    # Obtém as informações detalhadas do imóvel para locação
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_locacao.html', property=property)
    return "Imóvel não encontrado", 404

@app.route('/property/<int:id>')
def property_details_route(id):
    property = get_property_by_id(id)
    if property:
        return render_template('property_details.html', property=property)
    return "Imóvel não encontrado", 404

if __name__ == '__main__':
    app.run(debug=True)

@app.route('/comprar/<int:id>')
def detalhes_venda(id):
    # Obtém as informações detalhadas do imóvel para venda
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_venda.html', property=property)
    return "Imóvel não encontrado", 404

@app.route('/alugar/<int:id>')
def detalhes_locacao(id):
    # Obtém as informações detalhadas do imóvel para locação
    property = get_property_by_id(id)
    if property:
        return render_template('detalhes_locacao.html', property=property)
    return "Imóvel não encontrado", 404

