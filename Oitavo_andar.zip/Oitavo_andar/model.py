import sqlite3

DATABASE = 'imoveis.db'

# Função para inicializar o banco de dados e criar tabelas
def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    
    # Tabela de imóveis
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS properties (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price TEXT NOT NULL,
        address TEXT NOT NULL,
        status TEXT
    );
                   
    INSERT INTO imoveis (tipo, nome, descricao, quartos, banheiros, m2, preco, imagem)
    VALUES
    ('venda', 'Casa em São Paulo', '3 quartos, 2 banheiros, 150m²', 3, 2, 150, 500000, '/static/imovel1.jpg'),
    ('venda', 'Apartamento em Brasília', '2 quartos, 1 banheiro, 90m²', 2, 1, 90, 300000, '/static/imovel2.jpg'),
    ('venda', 'Loft em São Paulo', '1 quarto, 1 banheiro, 80m²', 1, 1, 80, 250000, '/static/imovel3.jpg');

    INSERT INTO imoveis (tipo, nome, descricao, quartos, banheiros, m2, preco, imagem)
    VALUES
    ('locacao', 'Apartamento em São Paulo', '2 quartos, 1 banheiro, 70m²', 2, 1, 70, 1500, '/static/imovel4.jpg'),
    ('locacao', 'Casa no Rio de Janeiro', '3 quartos, 2 banheiros, 120m²', 3, 2, 120, 2000, '/static/imovel5.jpg'),
    ('locacao', 'Estúdio em Brasília', '1 quarto, 1 banheiro, 40m²', 1, 1, 40, 800, '/static/imovel6.jpg');

    ''')
    
    # Tabela de corretores
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS realtors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )
    ''')
    
    # Insere dados fictícios, se necessário
    cursor.execute('SELECT COUNT(*) FROM properties')
    if cursor.fetchone()[0] == 0:
        cursor.executemany('''
        INSERT INTO properties (name, description, price, address, status)
        VALUES (?, ?, ?, ?, ?)
        ''', [
            ('Apartamento 1', 'Descrição do Apartamento 1', 'R$ 500.000', 'Rua ABC, São Paulo', None),
            ('Casa 2', 'Descrição da Casa 2', 'R$ 1.200.000', 'Avenida XYZ, Rio de Janeiro', None),
        ])
    
    cursor.execute('SELECT COUNT(*) FROM realtors')
    if cursor.fetchone()[0] == 0:
        cursor.executemany('''
        INSERT INTO realtors (username, password)
        VALUES (?, ?)
        ''', [
            ('corretor', '12345'),
            ('outro_corretor', 'senha')
        ])
    
    conn.commit()
    conn.close()

# Função para obter todos os imóveis
def get_all_properties():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM properties')
    rows = cursor.fetchall()
    conn.close()
    return [{'id': row[0], 'name': row[1], 'description': row[2], 'price': row[3], 'address': row[4]} for row in rows]

# Função para obter um imóvel pelo ID
def get_property_by_id(property_id):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM properties WHERE id = ?', (property_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return {'id': row[0], 'name': row[1], 'description': row[2], 'price': row[3], 'address': row[4]}
    return None

# Função para marcar um imóvel como vendido
def mark_as_sold(property_id):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("UPDATE properties SET status = 'sold' WHERE id = ?", (property_id,))
    conn.commit()
    conn.close()

# Função para marcar um imóvel como alugado
def mark_as_rented(property_id):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("UPDATE properties SET status = 'rented' WHERE id = ?", (property_id,))
    conn.commit()
    conn.close()

# Função para validar o login de um corretor
def validate_realtor_login(username, password):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM realtors WHERE username = ? AND password = ?", (username, password))
    realtor = cursor.fetchone()
    conn.close()
    return realtor

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Imovel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(20))
    nome = db.Column(db.String(100))
    descricao = db.Column(db.String(255))
    quartos = db.Column(db.Integer)
    banheiros = db.Column(db.Integer)
    m2 = db.Column(db.Integer)
    preco = db.Column(db.Float)
    imagem = db.Column(db.String(255))

class User(db.Model):
    id = db.column(db.Integer, primary_key=True)
    name = db.column(db.string(100), nullable=False)
    senha = db.column(db.string(30), nullable=False)
def init_db():
    db.create_all()

def get_property_by_id(id):
    return Imovel.query.get(id)

def get_all_properties(tipo):
    return Imovel.query.filter_by(tipo=tipo).all()

user = User(name="admin", senha='1234')
db.session.add(user)
db.session.commit()