from flask import jsonify
from DAO import *

class ImovelRepository:
    def __init__(self) -> None:
        self.ImovelDAO = ImovelDAO()

    def add_imovel(self, id, nome, tipo, descricao, quartos,banheiros, m2, preco, imagem):
        if not all([id, nome, tipo, descricao, quartos,banheiros, m2, preco, imagem]):
            return jsonify({"error": "Faltando informações"}), 400
        
        if len(id) != 64:
            return jsonify({"error": "Id inválido"}), 400
        
        imovel = self.ImovelDAO.add_imovel(id, nome, tipo, descricao, quartos,banheiros, m2, preco, imagem)
        
        return jsonify({
            "id": imovel.id,
            "nome": imovel.nome,
            "tipo": imovel.tipo,
            "descricao": imovel.descricao,
            "quartos": imovel.quartos,
            "banheiros": imovel.banheiros,
            "m2": imovel.m2,
            "preco": imovel.preco,
            "imagem": imovel.imagem
        }), 201

    def get_imovel_id(self, id):
        if not id:
            return jsonify({"error": "Faltando id"}), 400
        
        imovel, error = self.ImovelDAO.get_imovel_id(id)
        
        if error:
            return jsonify({"error": error}), 403
        
        return jsonify({
            "id": imovel.id,
            "nome": imovel.nome,
            "tipo": imovel.tipo,
            "descricao": imovel.descricao,
            "quartos": imovel.quartos,
            "banheiros": imovel.banheiros,
            "m2": imovel.m2,
            "preco": imovel.preco,
            "imagem": imovel.imagem
        })
