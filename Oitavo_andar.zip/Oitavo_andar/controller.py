from flask import render_template,request, redirect, url_for
from model import obter_imoveis_venda, obter_imoveis_locacao, obter_imovel_venda_por_id, obter_imovel_locacao_por_id, obter_imovel_por_id,get_property_by_id, mark_as_sold, mark_as_rented, validate_realtor_login

def home():
    # Obtém todos os imóveis para exibir na página inicial
    imoveis_venda = obter_imoveis_venda()
    imoveis_locacao = obter_imoveis_locacao()
    return render_template('index.html', imoveis_venda=imoveis_venda, imoveis_locacao=imoveis_locacao)

def comprar(id):
    imovel = get_property_by_id(id)
    if imovel:
        mark_as_sold(id)
    return redirect(url_for('venda'))

def alugar(id):
    imovel = get_property_by_id(id)
    if imovel:
        mark_as_rented(id)
    return redirect(url_for('locacao'))

def detalhes_venda(id):
    imovel = obter_imovel_venda_por_id(id)
    return render_template('detalhes_venda.html', imovel=imovel)

def detalhes_locacao(id):
    imovel = obter_imovel_locacao_por_id(id)
    return render_template('detalhes_locacao.html', imovel=imovel)

def property_details(id):
    # Obtém detalhes de um único imóvel com base no ID
    imovel = obter_imovel_por_id(id)
    return render_template('property_details.html', imovel=imovel)

def login_corretor():
    # Exemplo simplificado de lógica de login
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if validate_realtor_login(username, password):
            return redirect(url_for('home'))
        else:
            # Lidar com falha no login
            pass
    return render_template('login_corretor.html')
