from flask import Blueprint, session, flash, redirect, url_for

sessao_bp = Blueprint('sessao', __name__)

@sessao_bp.route('/definir_sessao')
def definir_sessao():
    session['usuario'] = 'Usuario123'
    flash("Sessão 'usuario' foi definida com sucesso!", "sucesso")
    return redirect(url_for('inicio'))

@sessao_bp.route('/obter_sessao')
def obter_sessao():
    usuario = session.get('usuario')
    if usuario:
        flash(f"Valor da sessão 'usuario': {usuario}", "info")
    else:
        flash("Sessão 'usuario' não encontrada.", "erro")
    return redirect(url_for('inicio'))

@sessao_bp.route('/limpar_sessao')
def limpar_sessao():
    session.clear()
    flash("Sessão limpa com sucesso!", "sucesso")
    return redirect(url_for('inicio'))
