from flask import Flask, render_template, flash, redirect, url_for
from exemplo_cookie import cookie_bp
from exemplo_sessao import sessao_bp
from exemplo_middleware import middleware_bp
from manipuladores_erro import erro_bp

app = Flask(__name__)
app.secret_key = 'chavesecreta'  # Necessário para sessões e mensagens flash

# Registrando blueprints
app.register_blueprint(cookie_bp)
app.register_blueprint(sessao_bp)
app.register_blueprint(middleware_bp)
app.register_blueprint(erro_bp)

@app.route('/')
def inicio():
    return render_template('inicio.html')

if __name__ == "__main__":
    app.run(debug=True)
