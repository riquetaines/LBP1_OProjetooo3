from flask import Blueprint

middleware_bp = Blueprint('middleware', __name__)

@middleware_bp.before_request
def antes_requisicao():
    print("Middleware: Requisição recebida")

@middleware_bp.after_request
def depois_requisicao(resposta):
    print("Middleware: Resposta enviada")
    return resposta
