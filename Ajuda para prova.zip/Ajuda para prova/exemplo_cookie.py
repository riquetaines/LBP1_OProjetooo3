from flask import Blueprint, request, make_response, flash, redirect, url_for

cookie_bp = Blueprint('cookie', __name__)

@cookie_bp.route('/definir_cookie')
def definir_cookie():
    resp = make_response(redirect(url_for('inicio')))
    resp.set_cookie('usuario', 'Usuario123')
    flash("Cookie 'usuario' foi definido com sucesso!", "sucesso")
    return resp

@cookie_bp.route('/obter_cookie')
def obter_cookie():
    usuario = request.cookies.get('usuario')
    if usuario:
        flash(f"Valor do cookie 'usuario': {usuario}", "info")
    else:
        flash("Cookie 'usuario' não encontrado.", "erro")
    return redirect(url_for('inicio'))
