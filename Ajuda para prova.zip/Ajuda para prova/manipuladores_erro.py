from flask import Blueprint, render_template, flash

erro_bp = Blueprint('erro', __name__)

@erro_bp.app_errorhandler(404)
def pagina_nao_encontrada(e):
    flash("Página não encontrada (Erro 404).", "erro")
    return render_template('404.html'), 404

@erro_bp.app_errorhandler(401)
def nao_autorizado(e):
    flash("Você não está autorizado a acessar esta página (Erro 401).", "erro")
    return render_template('401.html'), 401

@erro_bp.app_errorhandler(403)
def proibido(e):
    flash("Acesso proibido a esta página (Erro 403).", "erro")
    return render_template('403.html'), 403

@erro_bp.app_errorhandler(500)
def erro_servidor_interno(e):
    flash("Erro interno no servidor (Erro 500).", "erro")
    return render_template('500.html'), 500
